package com.example.myapplicationmealer;

import static android.content.ContentValues.TAG;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;


//added implememntation

public class ClientRegisterPage extends AppCompatActivity {

    private EditText editTextname, editTextLastName, editTextinputEmail, editTextpassword, editTextcreditCard, editTextCVV, editTextExpiry;
    private FirebaseAuth fAuth;
    private FirebaseFirestore fStore;
    private TextView creditText;
    Button donebutton, goBack;
    private String UserID;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_client_register_page);

         //setting done button's onclick
        donebutton = findViewById(R.id.donebutton);
        donebutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ondonebuttonClicked(donebutton);
            }
        });

        //setting the go back button
        goBack = findViewById(R.id.clientgoback);
        goBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(ClientRegisterPage.this, RegisterOptions.class);//takes you back to the main page
                startActivity(intent);
            }
        });

        editTextname = (EditText) findViewById(R.id.inputname);
        editTextLastName = (EditText) findViewById(R.id.inputlastname);
        editTextinputEmail = (EditText) findViewById(R.id.inputemail);
        editTextpassword = (EditText) findViewById(R.id.inputpass);
        editTextcreditCard = (EditText) findViewById(R.id.creditcard);
        editTextCVV = (EditText) findViewById(R.id.cvv);
        editTextExpiry = (EditText) findViewById(R.id.expiry);

        fAuth = FirebaseAuth.getInstance();
        fStore = FirebaseFirestore.getInstance();

    }
    private boolean verifyInputs(String inputemail,String inputpassword ){
        //Creating the getters for the inputs


        //Creating the error messages
        if (inputemail.isEmpty()) {
            editTextinputEmail.setError("Email is required");
            editTextinputEmail.requestFocus();
            return false;
        }

        if (!Patterns.EMAIL_ADDRESS.matcher(inputemail).matches()) {
            editTextinputEmail.setError("Please provide a valid email");
            editTextinputEmail.requestFocus();
            return false;
        }

        if (inputpassword.isEmpty()) {
            editTextpassword.setError("Password is required");
            editTextpassword.requestFocus();
            return false;
        }

        if (inputpassword.length() < 6) {
            editTextpassword.setError("Email is required");
            editTextpassword.requestFocus();
            return false;
        }
        return true;
    }
    private void ondonebuttonClicked(View view) {
        String inputname = editTextname.getText().toString().trim();
        String inputlastname = editTextLastName.getText().toString().trim();
        String inputemail = editTextinputEmail.getText().toString().trim();
        String inputpass = editTextpassword.getText().toString().trim();
        String creditcard = editTextcreditCard.getText().toString().trim();
        String cvv = editTextCVV.getText().toString().trim();
        String expiry = editTextExpiry.getText().toString().trim();

        if(!verifyInputs(inputemail,inputpass)){
            return;
        }

            fAuth.createUserWithEmailAndPassword(inputemail, inputpass)
                    .addOnCompleteListener(this, new OnCompleteListener<AuthResult>()
                    {
                        @Override
                        public void onComplete (@NonNull Task< AuthResult > task) {
                            //creating the user object

                            if (task.isSuccessful()) {
                                Toast.makeText(ClientRegisterPage.this, "Register has been successful", Toast.LENGTH_LONG).show();
                                DocumentReference documentReference = fStore.collection("Chefs").document(UserID);
                                User user = new User(inputemail, inputpass);
                                UserData dataUser = new UserData("Client", inputname, inputlastname, inputemail, inputpass, creditcard, cvv, expiry);
                                UserID = fAuth.getCurrentUser().getUid();
                                Map<String, Object> Clients = new HashMap<>();
                                Clients.put("lastname", inputname);
                                Clients.put("firstname", inputlastname);
                                Clients.put("password", inputpass);
                                Clients.put("firstname", creditcard);
                                Clients.put("firstname", cvv);
                                Clients.put("ExpiryDate", expiry);

                                documentReference.set(Clients).addOnSuccessListener(new OnSuccessListener<Void>() {
                                    @Override
                                    public void onSuccess(Void unused) {
                                        Log.d(TAG, "Registering has been succeful. the client id is" + UserID);
                                    }
                                }).addOnFailureListener(new OnFailureListener() {
                                    @Override
                                    public void onFailure(@NonNull Exception e) {
                                        Log.d(TAG, "Registering failed.");
                                    }
                                });
                                finish();//clear old activity. not allowed to go back
                            }
                            else{
                                    Toast.makeText(ClientRegisterPage.this, "Error!"+task.getException().getMessage(), Toast.LENGTH_SHORT);
                                 }


                        }
                    });

    }

}