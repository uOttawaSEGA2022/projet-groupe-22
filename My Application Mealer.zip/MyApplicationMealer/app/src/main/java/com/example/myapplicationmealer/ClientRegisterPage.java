package com.example.myapplicationmealer;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.location.Address;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;


//added implememntation

public class ClientRegisterPage extends AppCompatActivity {

    private EditText editTextname, editTextLastName, editTextinputEmail, editTextpassword, editTextcreditCard, editTextCVV, editTextExpiry;
    private FirebaseAuth fAuth;
    private FirebaseDatabase rootNode;
    private DatabaseReference reference;
    private TextView creditText, donebutton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_client_register_page);

         //setting done button's onclick
        donebutton = (Button) findViewById(R.id.donebutton);
        donebutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ondonebuttonClicked(donebutton);
            }
        });

        editTextname = (EditText) findViewById(R.id.inputname);
        editTextLastName = (EditText) findViewById(R.id.inputlastname);
        editTextinputEmail = (EditText) findViewById(R.id.inputemail);
        editTextpassword = (EditText) findViewById(R.id.inputpass);
        editTextcreditCard = (EditText) findViewById(R.id.creditcard);
        editTextCVV = (EditText) findViewById(R.id.cvv);
        editTextExpiry = (EditText) findViewById(R.id.expiry);

        fAuth = FirebaseAuth.getInstance();

    }
    private boolean verifyInputs(String inputemail,String inputpassword ){
        //Creating the getters for the inputs


        //Creating the error messages
        if (inputemail.isEmpty()) {
            editTextinputEmail.setError("Email is required");
            editTextinputEmail.requestFocus();
            return false;
        }

        if (!Patterns.EMAIL_ADDRESS.matcher(inputemail).matches()) {
            editTextinputEmail.setError("Please provide a valid email");
            editTextinputEmail.requestFocus();
            return false;
        }

        if (inputpassword.isEmpty()) {
            editTextpassword.setError("Password is required");
            editTextpassword.requestFocus();
            return false;
        }

        if (inputpassword.length() < 6) {
            editTextpassword.setError("Email is required");
            editTextpassword.requestFocus();
            return false;
        }
        return true;
    }
    private void ondonebuttonClicked(View view) {
        String inputname = editTextname.getText().toString().trim();
        String inputlastname = editTextLastName.getText().toString().trim();
        String inputemail = editTextinputEmail.getText().toString().trim();
        String inputpass = editTextpassword.getText().toString().trim();
        String creditcard = editTextcreditCard.getText().toString().trim();
        String cvv = editTextCVV.getText().toString().trim();
        String expiry = editTextExpiry.getText().toString().trim();

        if(!verifyInputs(inputemail,inputpass)){
            return;
        }

            fAuth.createUserWithEmailAndPassword(inputemail, inputpass)
                    .addOnCompleteListener(this, new OnCompleteListener<AuthResult>()
                    {
                        @Override
                        public void onComplete (@NonNull Task< AuthResult > task)
                        {
                            if (task.isSuccessful()) {   //creating the user object

                                if (task.isSuccessful()) {
                                    Toast.makeText(ClientRegisterPage.this, "Register has been successful", Toast.LENGTH_LONG).show();
                                    rootNode = FirebaseDatabase.getInstance();
                                    reference = rootNode.getReference("users");

                                    UserData dataUser = new UserData(inputname, inputlastname, inputemail, inputpass, creditcard, cvv, expiry);

                                    reference.child(inputname).setValue(dataUser);

                                } else {
                                    Toast.makeText(ClientRegisterPage.this, "Register has not been successful. Try again!", Toast.LENGTH_LONG).show();
                                }

                            }

                            else
                            {
                                Toast.makeText(ClientRegisterPage.this, "Register has not been successful. Try again!", Toast.LENGTH_LONG).show();
                            }
                        }
                    });

    }

}