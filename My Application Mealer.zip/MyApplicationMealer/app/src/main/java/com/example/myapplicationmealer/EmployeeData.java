package com.example.myapplicationmealer;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;

public class EmployeeData extends UserData {

    private String address;

    public EmployeeData() {

    }


    public EmployeeData (String m, String name,String lastname, String email,String password , String address) {
        super(m, name,lastname, email, password);
        this.address = address;
    }


    public String getAddress() {
        return address;
    }

    public void setAddress(String address){
        this.address = address;
    }
    public String getEmail() {
        return this.email;
    }

    public void setEmail(String email) {
        this.email = email;
    }


}
