package com.example.myapplicationmealer;


import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;


public class PageMain  extends AppCompatActivity {

    private FirebaseAuth mAuth;
    private Button signoutButton;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_page_main);

        signoutButton = (Button) findViewById(R.id.signoutButton);
        signoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                signOutUser();
            }
        });
    }

    void signOutUser(){
        mAuth.signOut();
        Intent intent = new Intent(this, MainActivity.class);//takes you back to the main page
        startActivity(intent);
        finish();
        Toast.makeText(PageMain.this, "The user is logging out", Toast.LENGTH_SHORT).show();
    }


}