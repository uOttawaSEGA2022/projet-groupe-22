package com.example.myapplicationmealer;

public class UserData {



    protected String name;
    protected String email;
    private boolean active;
    protected String pass;
    protected String lastname;
    protected String creditCard;
    protected String cvv;
    protected String expiry;

    // Constructor

    public UserData(){
        // Default constructor required for calls to DataSnapshot.getValue(User.class)
    }

    public UserData(String name, String lastname, String email, String pass, String creditCard, String cvv, String expiry ){
        this.name = name;
        this.lastname = lastname;
        this.pass = pass;
        this.email = email;
        this.creditCard = creditCard;
        this.cvv = cvv;
        this.expiry = expiry;
        active = true;
    }

    public String getName() {
        return name;
    }
    public String getLastname() {
        return lastname;
    }

    public String getPass() {
        return pass;
    }
    public String getEmail() {
        return this.email;
    }

    public void invertActive(){
        active = !active;
    }

    public boolean isActive() {
        return active;
    }



}